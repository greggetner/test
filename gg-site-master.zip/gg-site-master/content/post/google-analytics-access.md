---
title: "Google Analytics Access Instructions"
description: "Google Analytics access instructions"
date: 2019-02-11T23:45:03-07:00
tags: ["Client Onboarding Materials"]
draft: false

---

Welcome!

In order to get started we'll need to get access to your Google Analytics account.

Here are step-by-step instructions on how to do just that:

1. Head over to https://analytics.google.com
1. Navigate to your admin tab
1. On the far left "account" column, click on "User Management"
1. Click on the plus button and click "add users"
1. Enter `greg.getner@gmail.com` and check the "edit," "collaborate," and "read & analyze" boxes.

That's it, thank you. You're done!




